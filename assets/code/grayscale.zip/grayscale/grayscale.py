#!usr/bin/env/python

import os
import cv2
import numpy as np

# get path of this file
dir_path = os.path.dirname(os.path.realpath(__file__))
# get path of image. It's in the same folder as this file
img_path = os.path.join(dir_path, "udacity_logo.jpg")
# read the image
img = cv2.imread(img_path)
# convert the image to grayscale
gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# create empty matrix for 3 channel grayscale image
gray_img = np.zeros_like(img)
# give the grayscale image 3 channels of gray
gray_img[:, :, 0] = gray_image
gray_img[:, :, 1] = gray_image
gray_img[:, :, 2] = gray_image
# combine the input image and the grayscale image
output_img = vis = np.concatenate((img, gray_img), axis=1)

cv2.imshow("Udacity Robotics Nanodegree\
 Build & Brag Beginner Challenge #9", output_img)
cv2.waitKey(0)
cv2.destroyAllWindows()
